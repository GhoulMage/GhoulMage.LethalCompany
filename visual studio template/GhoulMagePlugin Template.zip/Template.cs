using GhoulMage.LethalCompany;
using BepInEx;
using BepInEx.Logging;
using System.Reflection;

namespace $safeitemname$_Namespace
{
    [BepInPlugin(GUID, NAME, VERSION)]
    [BepInProcess("Lethal Company.exe")]
    public class $safeitemname$ : GhoulMagePlugin
    {
        public const string GUID = "$safeitemname$.UNIQUE.GUID";
        public const string NAME = "$safeitemname$";
        public const string VERSION = "0.1.0";

        protected override LethalGameVersions GameCompatibility => new LethalGameVersions("v40", "v45");

        protected override Assembly AssemblyToPatch => Assembly.GetExecutingAssembly();

        internal static ManualLogSource Log;

        protected override void Initialize()
        {
            Log = Logger;
            base.Startup(GUID, NAME, VERSION, OnSuccesfulLoad, true);
        }
        private static void OnSuccesfulLoad()
        {
            Log.LogInfo("$safeitemname$ loaded...");
        }
    }
}
